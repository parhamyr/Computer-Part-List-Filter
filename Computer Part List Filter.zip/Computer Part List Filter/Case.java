/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class Case {
    
    String brand;
    String model;
    String size;
    String color;
    double price;

    /**
    * This is our default constructor
	* @param brand String param
	* @param model String param
	* @param size String param
	* @param color String param
	* @param price double param
	**/
    Case(String brand, String model, String size, String color, double price){
        this.brand = brand;
        this.model = model;
        this.size = size;
        this.color = color;
        this.price = price;
    }

    /**
	* This sets our Case brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    }
    /**
	* This gets our Case brand
	* @return this returns brand
	**/
    public String getBrand() {
        return brand;
    }

    /**
	* This sets our Case model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our Case model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }

    /**
	* This sets our Case size
	* @param size String param
	**/
    public void setSize(String size) {
        this.size = size;
    }
    /**
	* This gets our Case size
	* @return this returns size
	**/
    public String getSize() {
        return size;
    }

    /**
	* This sets our Case color
	* @param color String param
	**/
    public void setColor(String color) {
        this.color = color;
    }
    /**
	* This gets our Case color
	* @return this returns color
	**/
    public String getColor() {
        return color;
    }

    /**
	* This sets our Case price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our Case price
	* @return this returns price
	**/
    public double getPrice() {
        return price;
    }

    /**
	* This returns our full Case description
	* @return this returns String
	**/
    @Override
    public String toString(){
        return "Case: " + getBrand() + " " + getModel() + ", Size: " + getSize() + ", Color: " + getColor() + ", Price: $" + String.format("%.2f",getPrice()); 
    }

}
