/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class MotherBoard{
    
    String processor;
    String brand;
    String model;
    String size;
    double price;

    /**
    * This is our default constructor
	* @param processor String param
	* @param brand String param
	* @param model String param
	* @param size String param
	* @param price double param
	**/
    MotherBoard(String processor, String brand, String model, String size, double price) {
        this.processor = processor;
        this.brand = brand;
        this.model = model;
        this.size = size;
        this.price = price;
    }
    
    /**
    * This is the Chipset for the motherboard 
	* This sets our MotherBoard processor
	* @param processpr String param
	**/
    public void setProcessor(String processor) {
        this.processor = processor;
    }
    /**
	* This gets our MotherBoard processor
	* @return this returns processor
	**/
    public String getProcessor() {
        return processor;
    }

    /**
	* This sets our MotherBoard brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    }
    /**
	* This gets our MotherBoard brand
	* @return this returns brand
	**/
    public String getBrand() {
        return brand;
    }

    /**
	* This sets our MotherBoard model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our MotherBoard model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }
    
    /**
	* This sets our MotherBoard size
	* @param size String param
	**/
    public void setSize(String size) {
        this.size = size;
    }
    /**
	* This gets our MotherBoard size
	* @return this returns size
	**/
    public String getSize() {
        return size;
    }

    /**
	* This sets our MotherBoard price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our MotherBoard price
	* @return this returns size
	**/
    public double getPrice() {
        return price;
    }

    /**
	* This returns our full MotherBoard description
	* @return this returns String
	**/
    @Override
    public String toString() {
        return "Motherboard: " + getBrand() + " " + getModel() + ", Size: " + getSize() + ", Price: $" + String.format("%.2f",getPrice());
    }
}
