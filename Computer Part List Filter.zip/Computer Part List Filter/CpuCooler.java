/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class CpuCooler{
    
    String brand;
    String model;
    String cooling;
    int sound;
    double price;

    /**
    * This is our default constructor
	* @param brand String param
	* @param model String param
	* @param cooling String param
	* @param sound int param
	* @param price double param
	**/
    CpuCooler(String brand, String model,String cooling, int sound, double price) {
        this.brand = brand;
        this.model = model;
        this.cooling = cooling;
        this.sound = sound;
        this.price = price;
    }

    /**
	* This sets our CpuCooler brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    }
    /**
	* This gets our CpuCooler brand
	* @return this returns brand
	**/
    public String getBrand() {
        return brand;
    }

    /**
	* This sets our CpuCooler model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our CpuCooler model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }

    /**
	* This sets our CpuCooler cooling
	* @param cooling String param
	**/
    public void setCooling(String cooling) {
        this.cooling = cooling;
    }
    /**
	* This gets our CpuCooler cooling
	* @return this returns cooling
	**/
    public String getCooling() {
        return cooling;
    }
    
    /**
	* This sets our CpuCooler sound
	* @param sound int param
	**/
    public void setSound(int sound) {
        this.sound = sound;
    }
    /**
	* This gets our CpuCooler sound
	* @return this returns sound
	**/
    public int getSound() {
        return sound;
    }

    /**
	* This sets our CpuCooler price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our CpuCooler price
	* @return this returns price
	**/
    public double getPrice() {
        return price;
    }

    /**
	* This returns our full CpuCooler description
	* @return this returns String
	**/
    @Override
    public String toString() {
        return "CPU Cooler: " + getBrand() + " " + getModel() + ", " + getCooling() + " cooled, Max Decibals: " + getSound() + " dB, Price: $" + String.format("%.2f",getPrice());
    }
}
