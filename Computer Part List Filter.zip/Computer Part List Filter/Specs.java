/**
* @author Parham Raeesian
* @version 1.0.0
**/
public interface Specs {
    //This interface holds all of the generic methods to be implemented by CPU
    public String getBrand();
    public String getModel();
    public int getCores();
    public double getPrice();
    public String toString();
}

