/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class AMD extends CPU{
    String brand;
    String model;
    int cores;
    double price;
    /**
	* This  class extends our CPU abstract class
    * This is our default constructor
    * This calls the Parent class and puts the default brand "AMD"
	* @param model String param
	* @param cores int param
	* @param price double param
	**/
    AMD(String model, int cores, double price){
        super("AMD");
        this.model = model;
        this.cores = cores;
        this.price = price;
    }

    /**
	* This sets our CPU model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our CPU model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }
    /**
	* This sets our CPU cores
	* @param cores int param
	**/
    public void setCores(int cores) {
        this.cores = cores;
    }
    /**
	* This gets our CPU cores
	* @return this returns cores
	**/
    public int getCores() {
        return cores;
    }

    /**
	* This sets our CPU price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our CPU price
	* @return this returns price
	**/
    public double getPrice() {
        return price;
    }
    
    /**
    * This adds to our Parent class toString()
	* This returns our full CPU description
	* @return this returns String
	**/
    public String toString(){
        return super.toString() + " " + getModel() + ", Cores: " + getCores() + ", Price: $" + String.format("%.2f",getPrice());
    }
}
