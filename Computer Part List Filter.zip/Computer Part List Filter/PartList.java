import java.util.ArrayList;
import java.util.*;
import java.io.*;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.lang.String;
/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class PartList{
    /**
    * CpuList holds all the CPU part objects
    * GpuList holds all the GPU part objects
    * CpuCooler holds all the CpuCooler part objects
    * CpuList holds all the CPU part objects
    * CaseList holds all the Case part objects
    * MotherBoardList holds all the MotherBoard part objects
    * RamList holds all the RAM part objects
    * StorageList holds all the Storage part objects
    * 
    * parts holds all the part objects that the user has selected
    * cpu is a CPU variable that is pre-initialized to be used in our constructor;
    * preference is used to filter our CpuList
    * SelectedCpuType is the actual CPU type that the user has selected
    * This is later used by the MotherBoard to provide the compatible MotherBoardList for the selected CPU
    **/
    ArrayList<CPU> CpuList = new ArrayList<CPU>();
    ArrayList<GPU> GpuList = new ArrayList<GPU>();
    ArrayList<CpuCooler> CpuCoolerList = new ArrayList<CpuCooler>();
    ArrayList<MotherBoard> MotherBoardList = new ArrayList<MotherBoard>();
    ArrayList<Case> CaseList = new ArrayList<Case>();
    ArrayList<RAM> RamList = new ArrayList<RAM>();
    ArrayList<Storage> StorageList = new ArrayList<Storage>(); 
    ArrayList<Object> parts = new ArrayList<Object>();
    CPU cpu = new AMD("place holder", 0,0.0); 
    String preference = "Intel";
    String SelectedCpuType;

    /**
    * This is our default constructor
    * This takes a file name with parts inside it
    * a user can create can use their own partlist to filter through as long as it follows the same formatting
    * The constructor loops through the parts and adds them to its corresponding ArrayList
	* @param filename String param
	**/
    PartList(String filename) throws Exception{
        try{
            Scanner scnr = new Scanner(new File(filename));
            while(scnr.hasNextLine()){
                String [] line = scnr.nextLine().split(",",0);
                if (line[0].matches("CPU")){
					String brand = line[1];
					String model = line[2];
                    int cores = Integer.parseInt(line[3]);
                    double price = Double.parseDouble(line[4]);
                    if (brand.matches("Intel")){ // if CPU is Intel it will create instantiate the cpu variable and call the Intel class
                       cpu = new Intel(model,cores,price);
                    }
                    if (brand.matches("AMD")){// if AMD is Intel it will create instantiate the cpu variable and call the AMD class
                        cpu = new AMD(model,cores,price);
                    }
                    CpuList.add(cpu);

				}
				else if(line[0].matches("GPU")){
					String brand = line[1];
					String model = line[2];
                    String type = line[3];
                    double price = Double.parseDouble(line[4]);
                    GPU gpu = new GPU(brand, model, type, price);
                    GpuList.add(gpu);

				}
				else if(line[0].matches("CPU Cooler")){
					String brand = line[1];
					String model = line[2];
                    String cooling = line[3];
                    int sound = Integer.parseInt(line[4]);
                    double price = Double.parseDouble(line[5]);
                    CpuCooler cpucooler = new CpuCooler(brand, model, cooling, sound, price);
                    CpuCoolerList.add(cpucooler);
				}
				else if (line[0].matches("Motherboard")){
					String tmpProcessor = line[1];
                    String brand = line[2];
					String model = line[3];
                    String size = line[4];
                    double price = Double.parseDouble(line[5]);
                    MotherBoard motherBoard = new MotherBoard(tmpProcessor, brand, model, size, price);
                    MotherBoardList.add(motherBoard);
				}
				else if (line[0].matches("Case")){
					String brand = line[1];
					String model = line[2];
                    String size = line[3];
                    String color = line[4];
                    double price = Double.parseDouble(line[5]);
                    Case c = new Case(brand, model, size, color, price);
                    CaseList.add(c);

				}
				else if (line[0].matches("RAM")){
					String brand = line[1];
					String model = line[2];
                    int memory = Integer.parseInt(line[3]);
                    int modules = Integer.parseInt(line[4]);
                    int speed = Integer.parseInt(line[5]);
                    Double price = Double.parseDouble(line[6]);
                    RAM ram = new RAM(brand, model, memory, modules, speed, price);
                    RamList.add(ram);

				}
                else if (line[0].matches("Storage")){
					String brand = line[1];
					String model = line[2];
					String capacity = line[3];
                    String type = line[4];
                    double price = Double.parseDouble(line[5]);
                    Storage storage = new Storage(brand, model, capacity, type, price);
                    StorageList.add(storage);

				}
				else{
                    // For when our user creates their own file if there is an error it will easily tell them what the issue is in the file
					throw new Exception("Incorrect Part: " + line[0]);
				}
				
			}
			scnr.close();
            
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
    }

    /**
	* This returns a filtered version of our CpuList based on the amount of cores wanted
	* @param cores int param
    * @return ArrayList<CPU>
	**/
    public ArrayList<CPU> coreFilter(int cores){
        ArrayList<CPU> arr = new ArrayList<CPU>();
        if (preference.equals("Intel")){
            for (CPU cpu : CpuList){
                if (cpu.getBrand() == "Intel"){
                    if (cpu.getCores() >= cores){
                        arr.add(cpu);
                    }
                }
            }
        }
        else if (preference.equals("AMD")){
            for (CPU cpu : CpuList){
                if (cpu.getBrand() == "AMD"){
                    if (cpu.getCores() >= cores){
                        arr.add(cpu);
                    }
                }
            }
        }
        else{
            for (CPU cpu : CpuList){
                if (cpu.getCores() >= cores){
                    arr.add(cpu);
                }
            }
        }
        return arr;
        
    }

    /**
	* This returns a filtered version of our CpuCoolerList based on the type of cooling wanted 
	* @param cooling String param
    * @return ArrayList<CpuCoooler>
	**/
    public ArrayList<CpuCooler> coolerFilter(String cooling){
        ArrayList<CpuCooler> arr = new ArrayList<CpuCooler>();
        if (cooling.matches("Air")){
            for (CpuCooler cooler : CpuCoolerList){
                    if (cooler.getCooling().equals(cooling)){
                        arr.add(cooler);
                    }
                }
            }
        else if (cooling.matches("Liquid")){
            for (CpuCooler cooler : CpuCoolerList){
                    if (cooler.getCooling().equals(cooling)){
                        arr.add(cooler);
                    }
                }
            }
        else{
            arr = CpuCoolerList;
        }
        return arr;  
    }

    /**
	* This returns a compatible version of our MotherBoardList based on the type of CPU selected: Intel or AMD
	* @param brand String param
    * @return ArrayList<MotherBoard>
	**/
    public ArrayList<MotherBoard> brandFilter(String brand){
        ArrayList<MotherBoard> arr = new ArrayList<MotherBoard>();
            for (MotherBoard motherboard : MotherBoardList){
                if (motherboard.getProcessor().equals(brand)){
                    arr.add(motherboard);
                }
            }
        return arr;
    }

    /**
	* This returns a filtered version of our CaseList based on the color wanted 
	* @param color String param
    * @return ArrayList<Case>
	**/
    public ArrayList<Case> caseColorFilter(String color){
        ArrayList<Case> arr = new ArrayList<Case>();
            for (Case c : CaseList){
                if (c.getColor().equals(color)){
                    arr.add(c);
                }
            }
        return arr;
    }

    /**
	* This returns a filtered version of our RamList based on the amount of memory wanted 
	* @param memory int param
    * @return ArrayList<RAM>
	**/
    public ArrayList<RAM> ramMemoryFilter(int memory){
        ArrayList<RAM> arr = new ArrayList<RAM>();
            for (RAM ram : RamList){
                if (ram.getTotalMemory() == memory){
                    arr.add(ram);
                }
            }
        return arr;
    }

    /**
	* This returns a filtered version of our StorageList based on the type of Storage wanted: SSD or HDD
	* @param type String param
    * @return ArrayList<Storage>
	**/
    public ArrayList<Storage> storageTypeFilter(String type){
        ArrayList<Storage> arr = new ArrayList<Storage>();
            for (Storage storage : StorageList){
                if (storage.getType().equals(type)){
                    arr.add(storage);
                }
            }
        return arr;
    }

    /**
    * This prints all of the parts in arr with its index of list
    * This is done so that we always know what part the user selects
    * Even if the choose from the suggested or the entire part list
    * A generic is used so that we can use any of the part list types
	* @param arr ArrayList<T> param
	* @param list ArrayList<T> param
	**/
    public <T> void print(ArrayList<T> arr, ArrayList<T> list){
        for(T object : arr){
            System.out.println(list.indexOf(object) + ": " + object.toString());
        }
    }
    
    /**
    * This main method holds all the formatting and outputting
	* The file name can be changed by the user in line 281
    * bool is a variable used to determine whether the user wants to buy a certain part
    * this is incase they may already have the part or just arent interested in buying one
    * totalPrice tracks the total price of the parts selected by the user
	**/
    public static void main(String[] args) throws Exception {
         PartList p  = new PartList("Parts.csv");
            Scanner scanner = new Scanner(System.in);
            boolean bool;
            double totalPrice = 0.0;
        try{
            System.out.println("Hello what is your name?");
            String name = scanner.nextLine();
            System.out.println("-------------------------");
            System.out.println();

            System.out.println("What is your budget (Type just an integer): ");
            int budget = scanner.nextInt();
            System.out.println("-------------------------");
            System.out.println();

            System.out.println("Would you like to buy a CPU");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println();

            if (bool == true){
                System.out.println("Do you want an Intel processor or AMD processor or no preference");
                p.preference = scanner.next();
                System.out.println("At least how many cores do you want your CPU to have?");
                int cores = scanner.nextInt();
                System.out.println("Here is your suggested parts based on your filtration:");
                System.out.println();
                ArrayList<CPU> filtered = p.coreFilter(cores);
                p.print(filtered,p.CpuList); // we call out print method and use the filtered ArrayList and the CpuList ArrayList to get its index 
                System.out.println();
                System.out.println("Here is the total CPU part list:");
                System.out.println();
                p.print(p.CpuList,p.CpuList);
                System.out.println();
                System.out.println("Please select a CPU by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.CpuList.get(part));
                totalPrice += p.CpuList.get(part).getPrice();
                p.SelectedCpuType = p.CpuList.get(part).getBrand(); //we initialize the SelectedCpuType variable to be used my the motherboard later to provide the compatible motherboard list
                System.out.println();
                System.out.println("CPU Selected: " + p.CpuList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------");
                System.out.println();  
            }

            System.out.println("Would you like to buy a GPU?");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println();

            if (bool == true){
                System.out.println("Here is the total GPU part list:");
                System.out.println();
                p.print(p.GpuList,p.GpuList);
                System.out.println();
                System.out.println("Please select a GPU by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.GpuList.get(part));
                totalPrice += p.GpuList.get(part).getPrice();
                System.out.println();
                System.out.println("GPU Selected: " + p.GpuList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------");
                System.out.println();  
            }

            System.out.println("Would you like to buy a CPU Cooler?");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println();

            if (bool == true){
                System.out.println("Do you want an Air Cooled CPU cooler or a Liquid CPU Cooler or no preference");
                System.out.println(); //This is done so there is no room for error for filter selection
                System.out.println("0: Air Cooled CPU cooler");
                System.out.println("1: Liquid CPU Cooler");
                System.out.println("2: no preference");
                System.out.println();
                System.out.println("Please select a CPU Cooler type by entering the number beside the type you'd prefer");
                int cooltype = scanner.nextInt();
                ArrayList<CpuCooler> filtered;
                if(cooltype == 0){ 
                    filtered = p.coolerFilter("Air");
                }
                else if(cooltype == 1){
                    filtered = p.coolerFilter("Liquid");
                }
                else{
                    filtered = p.coolerFilter("none");
                }
                System.out.println("Here is your suggested parts based on your filtration:");
                System.out.println();
                p.print(filtered,p.CpuCoolerList);
                System.out.println();
                System.out.println("Here is the total CPU Cooler part list:");
                System.out.println();
                p.print(p.CpuCoolerList,p.CpuCoolerList);
                System.out.println();
                System.out.println("Please select a CPU Cooler by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.CpuCoolerList.get(part));
                totalPrice += p.CpuCoolerList.get(part).getPrice();
                System.out.println();
                System.out.println("CPU Cooler Selected: " + p.CpuCoolerList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------");
                System.out.println();  
            }

            System.out.println("Would you like to buy a Motherboard?");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println();

            if (bool == true){
                ArrayList<MotherBoard> filtered = new ArrayList<MotherBoard>();
                System.out.println("Here is your Motherboard part list:");
                System.out.println();
                if (p.SelectedCpuType == null){ //if the user never wanted a CPU then we just return the whole list of MotherBoards
                    p.print(p.MotherBoardList,p.MotherBoardList);
                }
                else{ //if they did chose  a CPU then it filters it and prints the compatible list of MotherBoards
                    filtered = p.brandFilter(p.SelectedCpuType);
                    p.print(filtered,p.MotherBoardList);
                }
                System.out.println();
                System.out.println("Please select a Motherboard by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.MotherBoardList.get(part));
                totalPrice += p.MotherBoardList.get(part).getPrice();
                System.out.println();
                System.out.println("Motherboard Selected: " + p.MotherBoardList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------");
                System.out.println();  
            }

            System.out.println("Would you like to buy a Case?");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println();

            if (bool == true){
                System.out.println("What case color would you like (type none for no preference)?");
                String color = scanner.next();
                ArrayList<Case> colorFiltered = p.caseColorFilter(color);
                System.out.println("Here is your suggested parts based on your filtration:");
                System.out.println();
                p.print(colorFiltered, p.CaseList);
                System.out.println();
                System.out.println("Here is the total Case part list:");
                System.out.println();
                p.print(p.CaseList,p.CaseList);
                System.out.println();
                System.out.println("Please select a Case by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.CaseList.get(part));
                totalPrice += p.CaseList.get(part).getPrice();
                System.out.println();
                System.out.println("Case Selected: " + p.CaseList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------");
                System.out.println();  
            }

            System.out.println("Would you like to buy RAM?");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println();

            if (bool == true){
                System.out.println("How many gigabytes of RAM would you like?");
                System.out.println();
                System.out.println("4");
                System.out.println("8");
                System.out.println("16");
                System.out.println("32");
                System.out.println("64");
                System.out.println("128");
                System.out.println("256");
                System.out.println();
                System.out.println("Please type the number of gigabytes of ram youd like from the given selection");
                int memory = scanner.nextInt();
                ArrayList<RAM> filtered = p.ramMemoryFilter(memory);
                System.out.println("Here is your suggested parts based on your filtration:");
                System.out.println();
                p.print(filtered, p.RamList);
                System.out.println();
                System.out.println("Here is the total RAM part list:");
                System.out.println();
                p.print(p.RamList,p.RamList);
                System.out.println();
                System.out.println("Please select a RAM by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.RamList.get(part));
                totalPrice += p.CaseList.get(part).getPrice();
                System.out.println();
                System.out.println("RAM Selected: " + p.RamList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------"); 
                System.out.println(); 
            }

            System.out.println("Would you like to buy a Storage Drive?");
            System.out.println("Please enter: true or false");
            bool = scanner.nextBoolean();
            System.out.println("-------------------------");
            System.out.println(); 

            if (bool == true){
                System.out.println("Would you like an SSD or an HDD (type none for no preference)");
                System.out.println();
                System.out.println("0: SSD");
                System.out.println("1: HDD");
                System.out.println("2: no preference");
                System.out.println();
                System.out.println("Please select a Storage type by entering the number beside the type you'd prefer");
                int type = scanner.nextInt();
                ArrayList<Storage> filtered;
                if(type == 0){ 
                    filtered = p.storageTypeFilter("SSD");
                }
                else if(type == 1){
                    filtered = p.storageTypeFilter("HDD");
                }
                else{
                    filtered = p.storageTypeFilter("none");
                }
                System.out.println("Here is your suggested parts based on your filtration:");
                System.out.println();
                p.print(filtered, p.StorageList);
                System.out.println("Here is the total Storage Drive part list:");
                System.out.println();
                p.print(p.StorageList,p.StorageList);
                System.out.println();
                System.out.println("Please select a Storage Drive by entering the number beside the part you'd like");
                int part = scanner.nextInt();
                p.parts.add(p.StorageList.get(part));
                totalPrice += p.CaseList.get(part).getPrice();
                System.out.println();
                System.out.println("Storage Selected: " + p.StorageList.get(part));
                System.out.println("Total Price: " + String.format("%.2f",totalPrice));
                System.out.println("-------------------------");  
                System.out.println(); 
            }

            System.out.println();
            System.out.println(name + "'s Computer Part List");
            System.out.println("_________________________________");
            p.print(p.parts,p.parts);
            System.out.println();
            
            File partFile = new File(name + "'s Computer Part List"); //This is so that the part list is personal to the user
            FileWriter fw = new FileWriter(partFile, true); //This makes it so that if the file already exists it is just appended to insted of overwritten
            PrintWriter pw = new PrintWriter(fw);
            pw.println(name + "'s Computer Part List");
              
            for(Object o : p.parts){
                pw.println(o.toString());
            }
            pw.println();
            pw.println("Budget Price: " + budget); //So that the user can compare the budget with the price of the total part list
                                                   // This is also done if they create multiple part lists in one file but with different budgets
            pw.println("Total Price: " + String.format("%.2f",totalPrice));
            pw.println();

            pw.close();
            scanner.close();

            System.out.println("A text file for your parts has sucessfuly been created in your folder under your name");
 
        }
        catch(InputMismatchException e){
            System.out.println("Incorrect Input");
        }
        catch(IndexOutOfBoundsException e){
            System.out.println("Select number that corresponds with part");
        }
    }
}
