/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class GPU {

    String brand;
    String model;
    String type;
    double price;

    /**
    * This is our default constructor
	* @param brand String param
	* @param model String param
	* @param type String param
	* @param price double param
	**/
    GPU(String brand, String model, String type, double price){
        this.brand = brand;
        this.model = model;
        this.type = type;
        this.price = price;
    }

    /**
	* This sets our GPU brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    
    }
    
    /**
	* This gets our GPU brand
	* @return this returns brand
	**/
    public String getBrand() {
        return brand;
    }

    /**
	* This sets our GPU model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our GPU model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }

    /**
	* This sets our GPU type
	* @param type String param
	**/
    public void setType(String type) {
        this.type = type;
    }
    /**
	* This gets our GPU type
	* @return this returns type
	**/
    public String getType() {
        return type;
    }
    
    /**
	* This sets our GPU price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our GPU price
	* @return this returns price
	**/
    public double getPrice() {
        return price;
    }

    /**
	* This returns our full GPU description
	* @return this returns String
	**/
    @Override
    public String toString(){
        return "GPU: " + getBrand() + " " + getModel() + " " + getType() + ", Price: $" + String.format("%.2f",getPrice());
    }

}
