/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class Storage {
    
    String brand;
    String model;
    String capacity;
    String type;
    double price;

    /**
    * This is our default constructor
	* @param brand String param
	* @param model String param
	* @param capacity String param
	* @param type String param
	* @param price double param
	**/
    Storage(String brand, String model, String capacity, String type, double price){
        this.brand = brand;
        this. model = model;
        this.capacity = capacity;
        this.type = type;
        this.price = price;
    }

    /**
	* This sets our Storage brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    }
    /**
	* This gets our Storage brand
	* @return this returns brand
	**/
    public String getBrand() {
        return brand;
    } 

    /**
	* This sets our Storage model
	* @param model String param
	**/
   public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our Storage model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }
    
    /**
	* This sets our Storage capacity
	* @param capacity String param
	**/
    public void setCapacity(String capacity) {
        this.capacity = capacity;
    }
    /**
	* This gets our Storage capacity
	* @return this returns capacity
	**/
    public String getCapacity() {
        return capacity;
    }

    /**
	* This sets our Storage type
	* @param type String param
	**/
    public void setType(String type) {
        this.type = type;
    }
    /**
	* This gets our Storage type
	* @return this returns type
	**/
    public String getType() {
        return type;
    }

    /**
	* This sets our Storage price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our Storage price
	* @return this returns price
	**/
    public double getPrice() {
        return price;
    }

    /**
	* This returns our full Storage description
	* @return this returns String
	**/
    @Override
    public String toString() {
        return "Storage: " + getBrand() + " " + getModel() + " " + getType() + ", Capacity: " + getCapacity() + ", Price: $" + String.format("%.2f",getPrice());
    }
    
}
