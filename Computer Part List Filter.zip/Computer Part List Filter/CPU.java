/**
* @author Parham Raeesian
* @version 1.0.0
**/
public abstract class CPU implements Specs{
    /**
	* This abstract class implements our Specs interface
    * This is our default constructor
	* @param brand String param
	**/
    String brand;
    String model;
    int cores;
    double price;

    CPU(String brand){
        this.brand = brand;
    }
    
    /**
	* This sets our CPU brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    }

    /**
	* This gets our CPU brand
	* @return this returns brand
	**/
    @Override
    public String getBrand() {
        return brand;
    }

     /**
	* This sets our CPU model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }

    /**
	* This gets our CPU model
	* @return this returns model
	**/
    @Override
    public String getModel() {
        return model;
    }

    /**
	* This sets our CPU cores
	* @param cores int param
	**/
    public void setCores(int cores) {
        this.cores = cores;
    }

    /**
	* This gets our CPU cores
	* @return this returns cores
	**/
    @Override
    public int getCores() {
        return cores;
    }

    /**
	* This sets our CPU price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }

    /**
	* This gets our CPU price
	* @return this returns price
	**/
    @Override
    public double getPrice() {
        return price;
    }

    /**
	* This returns our CPU description
	* @return this returns String
	**/
    @Override
    public String toString(){
        return "CPU: " + getBrand();
    }
}

