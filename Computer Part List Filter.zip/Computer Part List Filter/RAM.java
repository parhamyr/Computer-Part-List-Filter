

/**
* @author Parham Raeesian
* @version 1.0.0
**/
public class RAM {
    
    String brand;
    String model;
    int memory;
    int modules;
    int speed;
    double price;
    int totalMemory;
    
    /**
    * This is our default constructor
	* @param brand String param
	* @param model String param
	* @param memory int param
	* @param modules int param
	* @param speed int param
	* @param price double param
    * totalMemory variable is initialized by multilpying modules with memorys
	**/
    RAM(String brand, String model, int memory, int modules, int speed, double price){
        this.brand = brand;
        this.model = model;
        this.memory = memory;
        this.modules = modules;
        this.speed = speed;
        this.price = price;
        this.totalMemory = modules * memory;
    }

    /**
	* This sets our RAM brand
	* @param brand String param
	**/
    public void setBrand(String brand) {
        this.brand = brand;
    }
    /**
	* This gets our RAM brand
	* @return this returns brand
	**/
    public String getBrand() {
        return brand;
    }
    
    /**
	* This sets our RAM model
	* @param model String param
	**/
    public void setModel(String model) {
        this.model = model;
    }
    /**
	* This gets our RAM model
	* @return this returns model
	**/
    public String getModel() {
        return model;
    }

    /**
	* This sets our RAM memory
	* @param memmory int param
	**/
    public void setMemory(int memory) {
        this.memory = memory;
    }
    /**
	* This gets our RAM memory
	* @return this returns memory
	**/
    public int getMemory() {
        return memory;
    }

    /**
	* This sets our RAM modules
	* @param modules int param
	**/
    public void setModules(int modules) {
        this.modules = modules;
    }
    /**
	* This gets our RAM modules
	* @return this returns modules
	**/
    public int getModules() {
        return modules;
    }

    /**
	* This sets our RAM speed
	* @param speed int param
	**/
    public void setSpeed(int speed) {
        this.speed = speed;
    }
    /**
	* This gets our RAM speed
	* @return this returns speed
	**/
    public int getSpeed() {
        return speed;
    }
    
    /**
	* This sets our RAM price
	* @param price double param
	**/
    public void setPrice(double price) {
        this.price = price;
    }
    /**
	* This gets our RAM price
	* @return this returns price
	**/
    public double getPrice() {
        return price;
    }

    /**
	* This gets our RAM totalMemory
	* @return this returns totalMemory
	**/
    public int getTotalMemory() {
        return totalMemory;
    }
    
    /**
	* This returns our full RAM description
	* @return this returns String
	**/
    @Override
    public String toString(){
        return "RAM: " + getBrand() + " " + getModel() + " " + getTotalMemory() + " GB, Speed: DDR4-" + getSpeed() + " " + getModules() + " x " + getMemory() + "GB, Price: $" + String.format("%.2f",getPrice());
    }
}
